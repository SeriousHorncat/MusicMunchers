package com.ursarage.gameengine;


import com.badlogic.gdx.Gdx;
import com.ursarage.musicmunchers.GameScreen;
import com.ursarage.musicmunchers.MainMenuScreen;
import com.ursarage.musicmunchers.SplashScreen;

public class SceneManager {
	private BaseScene splashScene = new SplashScreen();
	private BaseScene menuScene = new MainMenuScreen();
	private BaseScene gameLevelScene = new GameScreen();

	private static final SceneManager INSTANCE = new SceneManager();
	
	private SceneType currentSceneType = SceneType.SCENE_SPLASH;
	private BaseScene currentScene;

  public enum SceneType
	{
		SCENE_SPLASH,
		SCENE_MENU,
		SCENE_GAME
	}
	
	public void setScene(BaseScene scene)
  {
    currentScene = scene;
    currentSceneType = scene.getSceneType();
    currentScene.resourcesManager.mGame.setScreen(currentScene); // refactor this
  }

public void setScene(SceneType sceneType)
  {
    switch (sceneType)
    {
      case SCENE_MENU:
        setScene(menuScene);
        break;
      case SCENE_GAME:
        setScene(gameLevelScene);
        break;
      case SCENE_SPLASH:
        setScene(splashScene);
        break;
//            case SCENE_LOADING:
//                setScene(loadingScene);
//                break;
//            case SCENE_WIN:
//            	setScene(winScene);
//            	break;
      default:
        break;
    }
  }

  //---------------------------------------------
  // GETTERS AND SETTERS
  //---------------------------------------------

  public static SceneManager getInstance() {
    return INSTANCE;
  }

  public SceneType getCurrentSceneType() {
    return currentSceneType;
  }

  public BaseScene getCurrentScene() {
    return currentScene;
  }

  public void createSplashScene() {
//    ResourceManager.getInstance().loadSplashScreen();
//    splashScene = new SplashScreen();
//    currentScene = splashScene;
  }

  private void disposeSplashScene() {
//    ResourceManager.getInstance().unloadSplashScreen();
//    splashScene.dispose();
//    splashScene = null;
  }

  public void createMenuScene() {
    ResourceManager.getInstance().loadMenuResources();
    menuScene = new MainMenuScreen();
    setScene(menuScene);
    disposeSplashScene();
  }

  public void loadGameScene() {
    Gdx.app.log("touch", "menuItemClicked Loading Game");

    ResourceManager.getInstance().loadGameResources();
    gameLevelScene = new GameScreen();
    setScene(gameLevelScene);
  }
}
