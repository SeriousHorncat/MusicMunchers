package com.ursarage.musicmunchers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.ursarage.gameengine.BaseScene;
import com.ursarage.gameengine.SceneManager;

/**
 * Created by Angelina on 7/18/13.
 */
public class MainMenuScreen extends BaseScene {

  public MainMenuScreen() {
  }

  @Override
  public void createScene() {
  }

  @Override
  public void render(float v) {
    Gdx.gl.glClearColor(0, 0, 0.2f, 1);
    Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);

    camera.update();
    mGame.batch.setProjectionMatrix(camera.combined);

    mGame.batch.begin();
    mGame.font.draw(mGame.batch, "Welcome to Drop!!! ", 100, 150);
    mGame.font.draw(mGame.batch, "Tap anywhere to begin!", 100, 100);
    mGame.batch.end();

    if (Gdx.input.isTouched()) {
        SceneManager.getInstance().loadGameScene();
        dispose();
    }
  }

  @Override
  public void resize(int i, int i2) {

  }

  @Override
  public void show() {

  }

  @Override
  public void hide() {

  }

  @Override
  public void pause() {

  }

  @Override
  public void resume() {

  }

  @Override
  public void dispose() {

  }

  @Override
  public SceneManager.SceneType getSceneType() {
    return SceneManager.SceneType.SCENE_SPLASH;
  }
}
