package com.ursarage.musicmunchers;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.ursarage.gameengine.ResourceManager;
import com.ursarage.gameengine.SceneManager;

public class MusicMunchersGame extends Game {
    SpriteBatch batch;
    BitmapFont font;

  ResourceManager resourceManager;

	@Override
	public void create() {
    font = new BitmapFont();
    batch = new SpriteBatch();

    resourceManager = resourceManager.getInstance();
    resourceManager.prepareManager(this);
    resourceManager.prepareSharedResources();

    SceneManager.getInstance().setScene(SceneManager.SceneType.SCENE_MENU);
  }


	@Override
	public void dispose() {
    batch.dispose();
    font.dispose();
	}

	@Override
	public void render() {		
		super.render();
  }


	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}
}
