package com.ursarage.musicmunchers;

import com.ursarage.gameengine.BaseScene;
import com.ursarage.gameengine.SceneManager;

/**
 * Created by Angelina on 7/20/13.
 */
public class SplashScreen extends BaseScene {
  @Override
  public void createScene() {

  }

  @Override
  public SceneManager.SceneType getSceneType() {
    return null;
  }

  @Override
  public void render(float v) {

  }

  @Override
  public void resize(int i, int i2) {
  }

  @Override
  public void show() {
  }

  @Override
  public void hide() {
  }

  @Override
  public void pause() {
  }

  @Override
  public void resume() {
  }

  @Override
  public void dispose() {
  }
}
