package com.ursarage.musicmunchers;


public interface MusicMuncherDefines {
	public static final int CELL_WIDTH = 75;
	public static final int CELL_HEIGHT = CELL_WIDTH;
}
